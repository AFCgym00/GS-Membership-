import type { VercelRequest, VercelResponse } from '@vercel/node';
import { buildClearedSessionCookie } from '../_lib/auth.js';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  res.setHeader('Set-Cookie', buildClearedSessionCookie());
  return res.status(200).json({ ok: true });
}
